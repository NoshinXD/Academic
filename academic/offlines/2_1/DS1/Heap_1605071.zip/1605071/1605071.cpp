#include<bits/stdc++.h>
using namespace std;

class MaxHeap
{
    int capacity;
    int current_size;
    int *A;

    int parent(int i)
    {
        return (i-1)/2;
    }
    int left(int i)
    {
        return (2*i + 1);
    }
    int right(int i)
    {
        return (2*i + 2);
    }

public :
    MaxHeap(int c)
    {
        current_size = 0;
        capacity = c;
        A = new int[c];
    }

    MaxHeap(int* arr,int c)
    {
        A = new int[c];
        current_size=c;
        capacity=c+10;
        for(int i=0; i<c; i++)
            A[i] = arr[i];

        Heapify();
    }

    void sift_up(int i)
    {
        if (A[parent(i)] < A[i])
        {
            swap(A[parent(i)], A[i]);
            sift_up(parent(i));
        }
    }

    void sift_down(int i)
    {
        int largest = i;

        if (left(i) < current_size && A[largest] < A[left(i)])
            largest = left(i);
        if (right(i) < current_size && A[largest] < A[right(i)])
            largest = right(i);
        if (i != largest)
        {
            swap(A[i], A[largest]);
            sift_down(largest);
        }
    }

    int find_Max()
    {
        if(current_size == 0)
            return INT_MAX;
        else
            return A[0];
    }

    void Heapify()
    {
        for(int i=current_size/2-1; i>=0; i-- )
            sift_down(i);
    }

    void increaseKey(int i, int key)
    {
        if(key < A[i])
        {
            printf("new key is smaller than current key\n");
            return;
        }
        A[i] = key;

        sift_up(i);
    }

    void decreaseKey(int i, int key)
    {
        if(key > A[i])
        {
            printf("new key is greater than current key\n");
            return;
        }
        A[i] = key;

        sift_down(i);
    }

    void updateKey(int i, int key)
    {
        /*if(key >= A[i])//increaseKey
        {
            cout<<"New key is greater or equal than current key."<<endl;
            A[i] = key;
            sift_up(i);
        }
        else//decreaseKey
        {
            cout<<"New key is smaller than current key"<<endl;
            A[i] = key;
            sift_down(i);
        }*/
        A[i] = key;
        if(key > A[parent(i)])
            sift_up(i);
        else
            sift_down(i);
    }

    void insert(int key)
    {
        /*if (current_size == capacity)
        {
            cout << "\nOverflow: Could not insertKey\n";
            return;
        }*/
        if(current_size == capacity)
            capacity = 2 * capacity;

        current_size++;
        A[current_size-1] = key;
        sift_up(current_size-1);
    }

    int extractMax()
    {
        if (current_size <= 0)
        {
            return INT_MIN;
        }

        int max = A[0];
        A[0] = A[current_size-1];
        current_size--;
        sift_down(0);
        return max;
    }

    void deleteMax()
    {
        if(current_size <= 0)
            cout<<"Heap is empty!!!"<<endl;
        else
        {
            A[0] = A[current_size-1];
            current_size--;
            sift_down(0);
        }
    }

    void replace(int val)
    {
        A[0] = val;
        sift_down(0);
    }

    void create_heap()
    {
        current_size = 0;
        A[0] = INT_MAX;
    }

    MaxHeap merge(MaxHeap &pq)
    {
        int current_size1 = this->current_size;
        int current_size2 = pq.current_size;
        int n = current_size1 + current_size2;
        MaxHeap mergedheap(n);
        mergedheap.current_size = n;

        for(int i=0; i<current_size1; i++)
            mergedheap.A[i] = this->A[i];

        for(int i=0; i<current_size2; i++)
            mergedheap.A[current_size1 + i] = pq.A[i];

        for(int i=(n/2) -1; i>=0; i--)
            mergedheap.sift_down(i);

        return mergedheap;
    }

    MaxHeap meld(MaxHeap &pq)
    {
        int current_size1 = this->current_size;
        int current_size2 = pq.current_size;
        int n = current_size1 + current_size2;
        MaxHeap mergedheap(n);
        mergedheap.current_size = n;

        for(int i=0; i<current_size1; i++)
            mergedheap.A[i] = this->A[i];
        //this->current_size = 0;
        delete(this);

        for(int i=0; i<current_size2; i++)
            mergedheap.A[current_size1 + i] = pq.A[i];
        //pq.current_size = 0;
        delete(&pq);

        for(int i=(n/2) -1; i>=0; i--)
            mergedheap.sift_down(i);

        return mergedheap;
    }

    int size()
    {
        return current_size;
    }

    bool is_empty()
    {
        return size() == 0;
    }

    void deleteKey(int i)
    {
        A[i] = A[current_size-1];
        current_size--;
        sift_down(i);
    }

    void print()
    {
        cout << this->current_size << endl;
        for(int i = 0; i < this->current_size; i++)
            cout<<this->A[i]<<"\t";
        printf("\n");
    }

    ~MaxHeap()
    {
        current_size = 0;
        capacity = 0;
        delete[] A;
    }
};

int main()
{
    MaxHeap h(50);

    while(1)
    {
        printf("1. Find-max. 2. Insert. 3. Extract-max.\n");
        printf("4. Delete-max. 5. replace. 6. Create-heap. 7. Heapify.\n");
        printf("8. Merge. 9. Meld. 10. Size. 11. Is-empty.\n");
        printf("12. Increase-key. 13. Decrease-key. 14.Delete\n");
        printf("15. Sift-up. 16. Sift-down. 17.Print. 18. exit. 19. Update-key\n");

        int ch;
        scanf("%d",&ch);
        if(ch==1)
        {
            if(h.find_Max() == INT_MAX)
                cout<<"Heap is empty!!!"<<endl;
            else
                cout<<"Max is "<<h.find_Max()<<endl;
        }
        else if(ch==2)
        {
            int k;
            cin>>k;
            h.insert(k);
        }
        else if(ch==3)
        {
            int heapMax = h.extractMax();
            if(heapMax==INT_MIN)
                cout<<"Heap is empty!!!"<<endl;
            else
                cout<<"Max is "<<heapMax<<endl;
        }
        else if(ch==4)
        {
            h.deleteMax();
        }

        else if(ch==5)
        {
            int k;
            cin>>k;
            h.replace(k);
        }
        else if(ch==6)
        {
            h.create_heap();
        }
        else if(ch==7)
        {
            //h.Heapify();
            int arr[7];
            for(int i=0; i<7; i++)
                cin>>arr[i];
            int size = 7;
            MaxHeap mh(arr, size);
            mh.print();
        }
        else if(ch==8)
        {
            MaxHeap h2(50);
            int a[3];
            for(int i =0 ; i < 3; i++)
            {
                cin>>a[i];
                h2.insert(a[i]);
            }

            MaxHeap asd = h.merge(h2);
            asd.print();
        }
        else if(ch==9)
        {
            MaxHeap h2(50);
            int a[3];
            for(int i =0 ; i < 3; i++)
            {
                cin>>a[i];
                h2.insert(a[i]);
            }
            MaxHeap asd = h.meld(h2);
            asd.print();
        }
        else if(ch==10)
        {
            //h.size();
            cout<<"Current size is "<<h.size()<<endl;
        }
        else if(ch==11)
        {
            if(h.is_empty() == true)
                cout<<"The heap is empty"<<endl;
            else
                cout<<"The heap is not empty"<<endl;
        }
        else if(ch==12)
        {
            int index, key;
            cin>>index;
            cin>>key;
            h.increaseKey(index, key);
        }
        else if(ch==13)
        {
            int index, key;
            cin>>index;
            cin>>key;
            h.decreaseKey(index,key);
            //h.updateKey(index,key);
        }
        else if(ch==14)
        {
            int key;
            cin>>key;
            h.deleteKey(key);
        }
        else if(ch==15)
        {
            int index;
            cin>>index;
            h.sift_up(index);
        }
        else if(ch==16)
        {
            int index;
            cin>>index;
            h.sift_down(index);
        }
        else if(ch==17)
        {
            h.print();
        }
        else if(ch==19)
        {
            int index, key;
            cin>>index;
            cin>>key;
            h.updateKey(index, key);
        }
        else if(ch==18)
        {
            break;
        }

    }
    return 0;
}

