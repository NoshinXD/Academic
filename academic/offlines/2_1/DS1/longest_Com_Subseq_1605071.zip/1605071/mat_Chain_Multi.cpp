#include<stdio.h>

#define INF_NUM 10000000

void Print_Optimal_Parens(int **s, int i, int j)
{
    if (i == j)
    {
        printf("A%d",i);
        return;
    }
    else
    {
        printf("(");
        Print_Optimal_Parens(s, i, s[i][j]);
        Print_Optimal_Parens(s, s[i][j] + 1, j);
        printf(")");
    }
}

void Matrix_Chain_Order(int p[], int length)
{
    int n = length;
    int m[n][n];
    int **s = new int*[n];
    for(int i=0; i<n; i++)
    {
        s[i]= new int[n];
    }

    int i, j, k, l, q = 0;

    for (i=1; i<n; i++)
        m[i][i] = 0;

    for (l=2; l<n; l++)
    {
        for (i=1; i<n-l+1; i++)
        {
            j = i+l-1;
            m[i][j] = INF_NUM;
            for (k=i; k<=j-1; k++)
            {
                q = m[i][k] + m[k+1][j] + p[i-1]*p[k]*p[j];
                if (q < m[i][j])
                {
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }
    printf("Minimum number of multiplications: %d\n", m[1][n-1]);
    printf("Order of multiplications: ");
    Print_Optimal_Parens((int**)s, 1, n-1);
}

int main()
{
    while(1)
    {
        int length,i;
        printf("Enter the size of matrix sequence(size should be greater than one): ");
        scanf("%d",&length);

        int p[length];

        printf("Enter the dimensions: ");
        for(i=0; i<length; i++)
        {
            scanf("%d",&p[i]);
        }

        Matrix_Chain_Order(p, length);
        printf("\n\n");
    }

    return 0;
}
