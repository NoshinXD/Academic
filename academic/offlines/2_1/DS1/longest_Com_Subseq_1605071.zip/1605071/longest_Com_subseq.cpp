#include<bits/stdc++.h>

int m=0,n=0;
char b[1000][1000];

int LCS_LENGTH(char *X, char *Y)
{
    m = strlen(X);
    n = strlen(Y);
    int i,j;

    int c[m+1][n+1];

    for(i=0; i<=m; i++)
        c[i][0] = 0;
    for(j=0; j<=n; j++)
        c[0][j] = 0;
    for(i=1; i<=m; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(X[i-1] == Y[j-1])
                //if(X[i-1] == Y[j-1] || X[i-1] == Y[j-1]+32 || X[i-1] == Y[i-1]-32)
            {
                c[i][j] = c[i-1][j-1] + 1;
                b[i][j] = 'c';
            }
            else if(c[i-1][j] >= c[i][j-1])
            {
                c[i][j] = c[i-1][j];
                b[i][j]= 'u';
            }
            else
            {
                c[i][j] = c[i][j-1];
                b[i][j] = 'd';
            }
        }
    }
    return c[m][n];
}

void PRINT_LCS(char *X, int i, int j)
{
    if(i==0 || j==0)
        return;
    if(b[i][j] == 'c')
    {
        PRINT_LCS(X, i-1, j-1);
        printf("%c",X[i-1]);
    }
    else if(b[i][j] == 'u')
    {
        PRINT_LCS(X, i-1, j);
    }
    else
    {
        PRINT_LCS(X, i, j-1);
    }
}

int main()
{
    while(1)
    {
        char X[1000], Y[1000];
        printf("Enter first sequence: ");
        gets(X);
        printf("Enter second subsequence: ");
        gets(Y);

        printf("\nLength of longest common subsequence is %d\n",LCS_LENGTH(X, Y));

        if(LCS_LENGTH(X, Y) == 0)
            printf("\nNo common subsequence!\n\n");
        else
        {
            printf("\nLCS for input sequences is ");
            PRINT_LCS(X,m,n);
            printf("\n\n");
        }
    }
    return 0;
}
