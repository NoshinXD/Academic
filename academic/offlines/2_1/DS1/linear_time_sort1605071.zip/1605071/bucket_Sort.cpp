#include <bits/stdc++.h>

using namespace std;

#define LIST_INIT_SIZE 2
#define NULL_VALUE -99999
#define SUCCESS_VALUE 99999

//const int MAX_N = 1000;


class ArrayList
{
    int listMaxSize;
    double * list;
    int length;
public:
    void initializeList()
    {
        listMaxSize = LIST_INIT_SIZE;
        list = (double*)malloc(sizeof(double)*listMaxSize) ;
        length = 0 ;
    }

    int insertItem(double newitem)
    {
        double * tempList ;
        if(listMaxSize==0)
        {
            initializeList();
        }
        if (length == listMaxSize)
        {
            //allocate new memory space for tempList
            listMaxSize = 2 * listMaxSize ;
            tempList = (double*) malloc (listMaxSize*sizeof(double)) ;
            int i;
            for( i = 0; i < length ; i++ )
            {
                tempList[i] = list[i] ; //copy all items from list to tempList
            }
            free(list) ; //free the memory allocated before
            list = tempList ; //make list to point to new memory
        };

        list[length] = newitem ; //store new item
        length++ ;
        return SUCCESS_VALUE ;
    }

    int shrink()
    {
        double * tempList ;
        if (length <= .5 * listMaxSize && listMaxSize > LIST_INIT_SIZE)
        {
            //allocate new memory space for tempList
            listMaxSize = .5 * listMaxSize ;
            tempList = (double*) malloc (listMaxSize*sizeof(double)) ;
            int i;
            for( i = 0; i < length ; i++ )
            {
                tempList[i] = list[i] ; //copy all items from list to tempList
            }
            free(list) ; //free the memory allocated before
            list = tempList ; //make list to point to new memory
        }
        //printf("S");

        //list[length] = newitem ; //store new item
        //length++ ;
        return SUCCESS_VALUE ;
    }

    int getLength()
    {
        return length;
    }

    //sorts the list
    void insertionSort()
    {
        int n = length;
        int i, j;
        double temp;
        for (i = 1; i < n; i++)
        {
            j = i-1;
            temp = list[i];

            while (j >= 0 && list[j] > temp)
            {
                list[j+1] = list[j];
                j = j-1;
            }
            list[j+1] = temp;
        }
    }

    double operator [] (int i)
    {
        if(i >= length or i < 0)
            return NULL_VALUE;
        return list[i];
    }

    /* void printList()
    {
        int i;
        for(i=0; i<length; i++)
            printf("%d ", list[i]);
        printf("Current size: %d, current length: %d\n", listMaxSize, length);
    } */
};

int main()
{
    while(1)
    {
        int n, idx = 0;
        ArrayList bucket[5];
        for (int i = 0; i < 5; i++)
        {
            bucket[i].initializeList();
        }
        double scale = 4.99, maxi = INT_MIN, mini = INT_MAX;

        cin >> n;
        double arr[n], ans[n];
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
            maxi = max(maxi, arr[i]);
            mini = min(mini, arr[i]);
        }

        if(maxi > mini)
        {
            scale = 4.99 / (maxi - mini);
            for (int i = 0; i < n; i++)
            {
                int j = (arr[i] - mini) * scale;
                bucket[j].insertItem(arr[i]);
            }

            for (int i = 0; i < 5; i++)
            {
                bucket[i].insertionSort();

                for (int j = 0; j < bucket[i].getLength(); j++)
                    ans[idx++] = bucket[i][j];
            }
        }
        else
        {
            for (int i = 0; i < n; i++)
                ans[i] = arr[i];
        }

        for (int i = 0; i < n; i++)
            cout << ans[i] << "\t";
        printf("\n\n");
    }

    return 0;
}
