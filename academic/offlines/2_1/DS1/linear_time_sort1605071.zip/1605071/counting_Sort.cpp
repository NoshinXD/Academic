#include <bits/stdc++.h>

using namespace std;

int main()
{
    while(1)
    {
        int minimum = 0, k = INT_MIN, idx = 0, n;

        cin >> n;
        int A[n], B[n];
        for (int i = 0; i < n; i++)
        {
            cin >> A[i];
            minimum = min(minimum, A[i]);
            k = max(k, A[i]);
        }
        for(int i = 0; i < n; i++)
        {
            A[i] = A[i] - minimum;
        }
        int newn = k-minimum+1;
        int C[newn];
        for(int i = 0; i < newn; i++)
            C[i] = 0;

        for (int i = 0; i < n; i++)
            C[A[i]]++;

        for(int i = 1; i < newn; i++)
            C[i] = C[i] + C[i-1];

        for(int j = n-1; j >=0; j--)
        {
            B[C[A[j]]-1] = A[j];
            C[A[j]] = C[A[j]] - 1;
        }

        for(int i=0; i<n; i++)
        {
            B[i]=B[i]+minimum;
        }

        for (int i = 0; i < n; i++)
            cout << B[i] << "\t";
        printf("\n\n");
    }

    return 0;
}

