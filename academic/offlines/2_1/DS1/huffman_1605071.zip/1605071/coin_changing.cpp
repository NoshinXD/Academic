#include <bits/stdc++.h>
using namespace std;

void coinChange(int arr[], int n, int V)
{
    int count[n], total=0;

    for(int i=0; i<n; i++)
    {
        count[i] = 0;
    }

    for (int i=n-1; i>=0; i--)
    {
        count[i] = V / arr[i];
        total = total + count[i];
        V = V % arr[i];
    }

    printf("%d\n",total);

    for(int i=n-1; i>=0; i--)
    {
        if(count[i]!=0)
        {
            printf("%d\t%d",arr[i],count[i]);
            printf("\n");
        }
    }
}


int main()
{
    int n,i,V;
    scanf("%d",&n);
    int arr[n];
    for(i=0; i<n; i++)
    {
        scanf("%d",&arr[i]);
    }
    scanf("%d",&V);

    sort(arr, arr+n);

    coinChange(arr, n, V);

    return 0;
}
