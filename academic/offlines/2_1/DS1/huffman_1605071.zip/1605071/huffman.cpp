#include <bits/stdc++.h>

using namespace std;

class Node
{
public:
    char ch;
    int freq;

    Node *left, *right;

    Node(char ch, int freq)
    {
        left = NULL;
        right = NULL;
        this->ch = ch;
        this->freq = freq;
    }

    Node()
    {
        ch = '@';
        freq = 0;
    }
};

class MyCompare
{
public:
    bool operator()(Node* l, Node* r)
    {
        if (l->freq > r->freq)
            return true;
        else return false;
    }
};

void huffmanCoding(Node *root, string code)
{
    if (root->left==NULL && root->right==NULL)
        cout << root->ch << "\t " << code << "\n";
    else {
        if (root->left!=NULL) huffmanCoding(root->left, code + "0");
        if (root->right!=NULL) huffmanCoding(root->right, code + "1");
    }

}

int main()
{
    int n, i;
    Node *left, *right, *top;

    priority_queue<Node*, vector<Node*>, MyCompare> nodePQ;

    cin>>n;
    char ch[n];
    int freq[n];

    for(i=0; i<n; i++)
    {
        cin>>ch[i]>>freq[i];
    }

    for (int i = 0; i < n; ++i)
        nodePQ.push(new Node(ch[i], freq[i]));

    while (nodePQ.size() > 1)
    {
        left = nodePQ.top();
        nodePQ.pop();

        right = nodePQ.top();
        nodePQ.pop();

        top = new Node('@', left->freq + right->freq);

        top->left = left;
        top->right = right;

        nodePQ.push(top);
    }

    string code = "";

    huffmanCoding(nodePQ.top(), code);

    return 0;
}

//a 5 b 9 c 12 d 13 e 16 f 45

