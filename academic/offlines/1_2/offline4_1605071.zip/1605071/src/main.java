import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class main
{
    private static ArrayList<CarMania>car = new ArrayList<CarMania>();

    public static void main(String[] args) {
        copyFromFile();
        while(true)
        {
            int choice;
            int choose;

            System.out.println("1. Search Car  2. Add Car  3. Delete Car");
            System.out.println("4. Exit System");
            System.out.println("Your choice: ");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();

            if(choice<=0 || choice>=5)
                System.out.println("Please enter valid input");
            else {
                switch (choice) {
                    case 1: {
                        System.out.println("1. Registration Number  2.Car Make & Car Model");
                        System.out.println("3. Back to main menu");
                        System.out.println("Your choice: ");
                        Scanner sca = new Scanner(System.in);
                        choose = sca.nextInt();
                        switch (choose) {
                            case 1: {
                                System.out.println("Enter Registrastion Number:");
                                Scanner reg = new Scanner(System.in);
                                String chr = reg.nextLine();
                                int counter = 0;
                                try {
                                    BufferedReader nbr = new BufferedReader(new FileReader("in.txt"));

                                    while (true) {
                                        String nline = nbr.readLine();
                                        if (nline == null)
                                            break;

                                        String[] str = nline.split(",");

                                        if (str[0].equalsIgnoreCase(chr)) {
                                            System.out.println("All information of this car:");
                                            System.out.println("Registration Number: " + str[0]);
                                            System.out.println("Year Made: " + str[1]);
                                            System.out.println("available color: " + str[2] + " " + str[3] + " " + str[4]);
                                            System.out.println("CarMake: " + str[5]);
                                            System.out.println("CarModel: " + str[6]);
                                            System.out.println("Price: " + str[7]);
                                            counter++;
                                            break;
                                        }
                                    }
                                    nbr.close();
                                    if (counter == 0)
                                        System.out.println("No such car with Registration Number.");
                                    counter = 0;
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                break;
                            }
                            case 2: {
                                System.out.print("Enter Car Make: ");
                                Scanner cmk = new Scanner(System.in);
                                String chr1 = cmk.nextLine();
                                System.out.print("Enter Car Model (You Can Input 'Any'): ");
                                String chr2 = cmk.nextLine();
                                try {
                                    BufferedReader nbr = new BufferedReader(new FileReader("in.txt"));

                                    while (true) {
                                        String nline = nbr.readLine();
                                        if (nline == null)
                                            break;
                                        String[] str = nline.split(",");

                                        if (chr2.equalsIgnoreCase("any") && str[5].equalsIgnoreCase(chr1)) {
                                            System.out.println("All information of this car:");
                                            System.out.println("Registration Number: " + str[0]);
                                            System.out.println("Year Made: " + str[1]);
                                            System.out.println("available color: " + str[2] + " " + str[3] + " " + str[4]);
                                            System.out.println("CarMake: " + str[5]);
                                            System.out.println("CarModel: " + str[6]);
                                            System.out.println("Price: " + str[7]);
                                        } else if (chr2.equalsIgnoreCase(str[6]) && str[5].equalsIgnoreCase(chr1)) {
                                            System.out.println("All information of this car:");
                                            System.out.println("Registration Number: " + str[0]);
                                            System.out.println("Year Made: " + str[1]);
                                            System.out.println("available color: " + str[2] + " " + str[3] + " " + str[4]);
                                            System.out.println("CarMake: " + str[5]);
                                            System.out.println("CarModel: " + str[6]);
                                            System.out.println("Price: " + str[7]);
                                        }
                                    }
                                    nbr.close();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                break;
                            }
                            default:
                                break;
                        }
                        if (choose == 3) {
                            System.out.println("Back to main menu");
                            break;
                        }
                        System.out.println("1. Search Car  2. Add Car  3. Delete Car");
                        System.out.println("4. Exit System");
                        System.out.println("Your choice: ");
                        break;
                    }

                    case 2: {
                        String regno = new String();
                        String clr1 = new String();
                        String clr2 = new String();
                        String clr3 = new String();
                        String cm1 = new String();
                        String cm2 = new String();
                        int ym, p, clr, counter = 0;

                        Scanner ip = new Scanner(System.in);

                        System.out.print("Enter Registration Number: ");
                        regno = ip.next();

                        System.out.println("Enter Year Made: ");
                        ym = ip.nextInt();

                        System.out.println("Enter Number of availabler Colour(not more than 3): ");
                        clr = ip.nextInt();

                        System.out.println("Enter The colours: ");

                        if (clr == 0) {
                            clr1 = "";
                            clr2 = "";
                            clr3 = "";
                        }
                        if (clr == 1) {
                            clr1 = ip.next();
                            clr2 = "";
                            clr3 = "";
                        } else if (clr == 2) {
                            clr1 = ip.next();
                            clr2 = ip.next();
                            clr3 = "";
                        } else if (clr >= 3) {
                            clr1 = ip.next();
                            clr2 = ip.next();
                            clr3 = ip.next();
                        }

                        System.out.println("Enter Car Make: ");
                        cm1 = ip.next();

                        System.out.println("Enter Car Model: ");
                        cm2 = ip.next();

                        System.out.println("Enter Car Price: ");
                        p = ip.nextInt();

                        try {
                            BufferedReader nbr = new BufferedReader(new FileReader("in.txt"));

                            while (true) {
                                String nline = nbr.readLine();
                                if (nline == null)
                                    break;

                                String[] str = nline.split(",");

                                if (str[0].equalsIgnoreCase(regno)) {
                                    System.out.println("There is already a car using the same Registration Number.!!! Registration number should be unique one!!!");
                                    counter++;
                                }
                            }
                            nbr.close();

                            if (counter == 0) {
                                CarMania c = new CarMania(regno, ym, clr1, clr2, clr3, cm1, cm2, p);
                                copyFromFile();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                    case 3: {
                        Scanner st = new Scanner(System.in);
                        System.out.println("Enter a Registration Number: ");
                        String regno = st.next();

                        try {
                            BufferedReader br = new BufferedReader(new FileReader("in.txt"));
                            BufferedWriter bw = new BufferedWriter(new FileWriter(("out.txt")));

                            while (true) {
                                String line = br.readLine();
                                if (line == null) break;
                                String[] str = line.split(",");
                                if (str[0].equalsIgnoreCase(regno) == false)
                                    bw.write(line + "\n");
                            }
                            br.close();
                            bw.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        try {
                            BufferedReader br = new BufferedReader(new FileReader("out.txt"));
                            BufferedWriter bw = new BufferedWriter(new FileWriter("in.txt"));

                            while (true) {
                                String line = br.readLine();
                                if (line == null) break;
                                bw.write(line + "\n");
                            }
                            br.close();
                            bw.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        copyFromFile();
                        break;
                    }
                    default:
                        break;

                }
                if (choice == 4)
                    break;
            }
        }
    }
    public static void copyFromFile()
    {
        car.clear();

        try{
            BufferedReader br = new BufferedReader(new FileReader("in.txt"));

            while(true)
            {
                String line = br.readLine();
                if(line == null) break;

                String[] data = line.split("\\,");

                CarMania c = new CarMania(data[0], Integer.parseInt(data[1]), data[2], data[3], data[4], data[5],data[6], Integer.parseInt(data[7]),1);
                car.add(c);
            }
        }catch (Exception e){
            //e.printStackTrace();
        }
        /*for (CarMania x: car)
            System.out.println(x.getPrice());*/
    }
}

