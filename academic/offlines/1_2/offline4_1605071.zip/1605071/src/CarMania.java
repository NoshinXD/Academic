import java.awt.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class CarMania
{
    String Car_Reg;
    int Year_Made;
    String Colour1,Colour2,Colour3;
    String Car_Make;
    String Car_Model;
    int Price;

    public String getCar_Reg() {
        return Car_Reg;
    }

    public int getYear_Made() {
        return Year_Made;
    }

    public String getColour1() {
        return Colour1;
    }

    public String getColour2() {
        return Colour2;
    }

    public String getColour3() {
        return Colour3;
    }

    public String getCar_Make() {
        return Car_Make;
    }

    public String getCar_Model() {
        return Car_Model;
    }

    public int getPrice() {
        return Price;
    }

    public CarMania(String car_Reg, int year_Made, String colour1, String colour2, String colour3, String car_Make, String car_Model, int price) {
        Car_Reg = car_Reg;
        Year_Made = year_Made;
        Colour1 = colour1;
        Colour2 = colour2;
        Colour3 = colour3;
        Car_Make = car_Make;
        Car_Model = car_Model;
        Price = price;

        String str = Car_Reg+","+Integer.toString(Year_Made)+","+Colour1+","+Colour2+","+Colour3+","+Car_Make+","+Car_Model+","+Integer.toString(Price);
        fileWork(str);
    }

    public CarMania(String car_Reg, int year_Made, String colour1, String colour2, String colour3, String car_Make, String car_Model, int price, int x) {
        Car_Reg = car_Reg;
        Year_Made = year_Made;
        Colour1 = colour1;
        Colour2 = colour2;
        Colour3 = colour3;
        Car_Make = car_Make;
        Car_Model = car_Model;
        Price = price;
    }

    public void fileWork(String str)
    {
        try {
            BufferedReader br = new BufferedReader(new FileReader("in.txt"));
            BufferedWriter bw = new BufferedWriter(new FileWriter("out.txt"));

            while (true){
                String line = br.readLine();
                if (line == null) break;
                bw.write(line+"\n");
            }
            bw.write(str);
            br.close();
            bw.close();
        } catch (Exception e){
            e.printStackTrace();
        }

        try {
            BufferedReader br = new BufferedReader(new FileReader("out.txt"));
            BufferedWriter bw = new BufferedWriter(new FileWriter("in.txt"));

            while (true){
                String line = br.readLine();
                if (line == null) break;
                bw.write(line+"\n");
            }
            br.close();
            bw.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
