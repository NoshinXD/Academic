import java.util.Scanner;

class MyException extends Exception{
    public MyException() {
    }
}

public class Inheritance {


    public static void main(String[] args) {

        int choice;
        int[] counter = new int[5];
        Scanner sc = new Scanner(System.in);
        Shape shape;

        while (true) {
            System.out.println("Please select your choice: ");
            System.out.println("1. Circle");
            System.out.println("2. Cylinder");
            System.out.println("3. Sphere");
            System.out.println("4. Square");
            System.out.println("5. Cube");

            choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1: {
                        try {
                            System.out.print("Enter radius: ");
                            double radius = sc.nextDouble();

                            if (radius < 0) {
                                throw new MyException();
                            } else {
                                counter[0]++;
                                System.out.println("Name: Circle" + counter[0]);
                                shape = new Circle(radius);
                                System.out.println("Area: " + shape.area());
                            }
                        } catch (MyException e) {
                            System.out.println("You can not enter negative value");
                        }
                        break;
                    }

                    case 2: {
                        try {
                            System.out.print("Enter radius: ");
                            double radius = sc.nextDouble();

                            System.out.print("Enter height: ");
                            double height = sc.nextDouble();

                            if (radius < 0 || height < 0)
                                throw new MyException();
                            else {
                                counter[1]++;
                                System.out.println("Name: Cylinder" + counter[1]);
                                shape = new Cylinder(radius,height);
                                System.out.println("Area of the base: " + shape.area());
                                System.out.println("Area of surface: " + shape.surarea());
                                System.out.println("Volume: " + shape.volume());
                            }
                        } catch (MyException e) {
                            System.out.println("You can not enter negative value");
                        }
                        break;
                    }
                    case 3: {
                        try {
                            System.out.print("Enter radius: ");
                            double radius = sc.nextDouble();

                            if (radius < 0)
                                throw new MyException();
                            else {
                                counter[2]++;
                                System.out.println("Name: Sphere" + counter[2]);
                                shape = new Sphere(radius);
                                System.out.println("Volume: " + shape.volume());
                            }
                        } catch (MyException e) {
                            System.out.println("You can not enter negative value");
                        }
                        break;
                    }
                    case 4: {
                        try {
                            System.out.print("Enter length: ");
                            double length = sc.nextDouble();
                            if (length < 0)
                                throw new MyException();
                            else {
                                counter[3]++;
                                System.out.println("Name: Square" + counter[3]);
                                shape = new Square(length);
                                System.out.println("Area: " + shape.area());
                            }
                        } catch (MyException e) {
                            System.out.println("You can not enter negative value");
                        }
                        break;
                    }
                    case 5: {
                        try {
                            System.out.print("Enter length: ");
                            double length = sc.nextDouble();
                            if (length < 0)
                                throw new MyException();
                            else {
                                counter[4]++;
                                System.out.println("Name: Cube" + counter[4]);
                                shape = new Cube(length);
                                System.out.println("Volume: " + shape.volume());
                            }
                        } catch (MyException e) {
                            System.out.println("You can not enter negative value");
                        }
                        break;
                    }
                    default:
                        throw new MyException();
                }
            } catch (MyException e) {
                System.out.println("You can not enter invalid input");
            }
        }
    }
}