public interface Volume {
    double volume();
}
