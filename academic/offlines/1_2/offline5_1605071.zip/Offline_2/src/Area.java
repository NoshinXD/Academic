public interface Area {
    double area();
    double surarea();
}
