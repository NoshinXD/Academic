public class Cylinder extends Shape{
    private double height,radius;

    public Cylinder(double radius, double height) {
        this.height = height;
        this.radius = radius;
    }

    @Override
    public double area() {
        return 3.1416*radius*radius;
    }

    @Override
    public double surarea() {
        return 2*3.1416*radius*height;
    }

    @Override
    public double volume() {
        return 3.1416*radius*radius*height;
    }
}
