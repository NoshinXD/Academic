public class Sphere extends Shape{
    private double radius;

    public Sphere(double radius)
    {
        this.radius = radius;
    }

    @Override
    public double volume() {
        return (4.0/3.0)*3.1416*radius*radius*radius;
    }
}
