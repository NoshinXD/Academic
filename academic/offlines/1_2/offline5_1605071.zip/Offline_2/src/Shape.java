public class Shape implements Area,Volume {
    @Override
    public double area() {
        return 0;
    }

    @Override
    public double surarea() {
        return 0;
    }

    @Override
    public double volume() {
        return 0;
    }
}

