public class Cube extends Shape{
    private double length;

    public Cube(double length)
    {
        this.length = length;
    }

    @Override
    public double volume() {
        return length*length*length;
    }

}
